#!/usr/bin/env bash

. /hive/miners/custom/XelisCPU/h-manifest.conf

stats_raw=`curl -s 'http://localhost:41353/stats'`

if [[ $? -ne 0 || -z $stats_raw ]]; then
    echo -e "${YELLOW}Failed to read $miner from localhost:41353${NOCOLOR}"
else
    local stats_array=()
    for value in $stats_raw; do stats_array+=($value); done

    local temp=`/hive/sbin/cpu-temp`

    local hs=${stats_array[0]}
    local uptime=${stats_array[1]}
    local ver=${stats_array[2]}
    local acc=${stats_array[3]}
    local rej=${stats_array[4]}

    local khs=`printf "%.3f" "${hs}e-3"`
    stats=$(cat <<-END
{
    "hs": [$hs],
    "hs_units": "hs",
    "temp": [$temp],
    "uptime": $uptime,
    "ver": \"$ver\",
    "ar": [$acc, $rej],
    "algo": "xelis_hash"
}
END
)
fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
