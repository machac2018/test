#!/usr/bin/env bash

if [[ $CUSTOM_URL == wss* ]];
then
    USERNAME=`echo $CUSTOM_TEMPLATE | cut -d . -f 1`
else
    USERNAME=$CUSTOM_TEMPLATE
fi
echo -e "--daemon-address=$CUSTOM_URL -m $USERNAME --api-listen=127.0.0.1:41353 $CUSTOM_USER_CONFIG" > $CUSTOM_CONFIG_FILENAME
