#!/usr/bin/env bash

. h-manifest.conf

./xlarig $(< ./$CUSTOM_NAME.conf) --log-file=$CUSTOM_LOG_BASENAME.log
